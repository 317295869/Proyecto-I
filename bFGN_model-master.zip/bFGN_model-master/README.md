# bFGN_model

This folder contains a reference implementation of the computational framework proposed in

"Boolean Factor Graph Model for Biological Systems: The Yeast Cell-Cycle Network" submitted to the BMC Bioinformatics

by S. Kotiang, and A. Eslami

For further details see the uploaded ReadMe.txt file
